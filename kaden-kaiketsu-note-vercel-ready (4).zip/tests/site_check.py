#!/usr/bin/env python3
"""Site integrity audit for the generated static site (does not contact the internet)."""
from pathlib import Path
from bs4 import BeautifulSoup
from urllib.parse import urlsplit,unquote
import json,sys
root=Path(__file__).resolve().parents[1]
site=root/'site'
errors=[];warnings=[]
paths=list(site.rglob('*.html'))
for f in paths:
    rel=f.relative_to(site)
    dom=BeautifulSoup(f.read_text(encoding='utf8'),'html.parser')
    if not dom.title: errors.append(f'{rel}: missing <title>')
    if not dom.select_one('meta[name="description"]'): errors.append(f'{rel}: missing description')
    if not dom.select_one('main'): errors.append(f'{rel}: missing main')
    if f.name=='index.html' and not dom.select_one('h1'):errors.append(f'{rel}: missing h1')
    for tag in dom.select('[href]'):
        url=tag['href']
        if url.startswith(('http:','https:','mailto:','tel:','data:')): continue
        spl=urlsplit(url)
        if not spl.path.startswith('/') and not spl.path.startswith('#'):
            continue
        target=site/unquote(spl.path.lstrip('/')) if spl.path else f
        if target.is_dir():target=target/'index.html'
        if not target.is_file(): errors.append(f'{rel}: missing link target {url}')
        elif spl.fragment and target.suffix=='.html':
            to=BeautifulSoup(target.read_text(encoding='utf8'),'html.parser')
            if not to.find(id=unquote(spl.fragment)):
                errors.append(f'{rel}: missing anchor {url}')
    for script in dom.select('script[type="application/ld+json"]'):
        try: json.loads(script.string)
        except Exception as e:errors.append(f'{rel}: invalid structured data {e}')

articles=json.loads((root/'content'/'articles.json').read_text(encoding='utf8'))
assert len(articles)==10, 'Expected 10 starter articles'
for a in articles:
    if not a['sources']:errors.append(f"{a['slug']}: no sources")
    if len(a['steps'])<3:errors.append(f"{a['slug']}: steps too few")
    if not (site/'articles'/a['slug']/'index.html').is_file():errors.append(f"{a['slug']}: missing page")
if not (site/'sitemap.xml').exists():
    if 'Disallow: /' not in (site/'robots.txt').read_text():errors.append('Preview must not be indexed')
    if not BeautifulSoup((site/'index.html').read_text(),'html.parser').select_one('meta[name="robots"][content="noindex,nofollow"]'):
        errors.append('Preview missing noindex')
if '公開前に運営者名' in (site/'about/index.html').read_text():
    warnings.append('運営者名・連絡先の本番掲載が未完了')
if '公開前に連絡先' in (site/'privacy/index.html').read_text():
    warnings.append('問い合わせ先の本番掲載が未完了')
print(f'Checked {len(paths)} HTML files, {len(articles)} guides')
for m in warnings:print('WARNING',m)
for m in errors:print('ERROR',m)
if errors:sys.exit(1)
print('PASS - Internal links, anchors, metadata, JSON-LD, and preview indexing')

#!/usr/bin/env python3
"""Browser check using in-memory HTML (works in sandboxes that block localhost navigation)."""
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT/'site'
css=(SITE/'assets/styles.css').read_text(encoding='utf-8')
css='\n'.join(x for x in css.splitlines() if not x.startswith('@import'))
js=(SITE/'assets/main.js').read_text(encoding='utf-8')

def render(page,pathname):
    page.set_content((SITE/pathname).read_text(encoding='utf-8'),wait_until='domcontentloaded')
    page.add_style_tag(content=css)
    page.add_script_tag(content=js)

with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 errors=[]
 page=browser.new_page(viewport={'width':1280,'height':800},device_scale_factor=1)
 page.on('pageerror',lambda error: errors.append(str(error)))
 page.evaluate('''() => {
   window.__fakeStore = {};
   Object.defineProperty(window,'localStorage',{ configurable:true, value:{
     getItem: k => window.__fakeStore[k] ?? null,
     setItem:(k,v) => {window.__fakeStore[k] = v;},
     removeItem:k => {delete window.__fakeStore[k];}
   } });
 }''')
 render(page,Path('index.html'))
 assert page.locator('#result-count').inner_text()=='10'
 page.locator('#site-search').fill('SwitchBot')
 assert page.locator('#result-count').inner_text()=='3'
 page.locator('#site-search').fill('zzz-unknown')
 assert page.locator('#empty-state').is_visible()
 page.locator('#reset-search').click()
 assert page.locator('#result-count').inner_text()=='10'
 render(page,Path('articles/fire-tv-wifi-connect/index.html'))
 checks=page.locator('.step-check input')
 assert checks.count()==4
 checks.nth(0).check()
 assert '1 / 4' in page.locator('.check-progress-label').inner_text()
 render(page,Path('articles/fire-tv-wifi-connect/index.html'))
 assert page.locator('.step-check input').nth(0).is_checked()
 page.locator('.check-reset').click()
 assert not page.locator('.step-check input').nth(0).is_checked()
 page.screenshot(path=str(ROOT/'article-checklist-preview.png'),full_page=False)
 mobile=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
 mobile.on('pageerror',lambda error: errors.append(str(error)))
 render(mobile,Path('index.html'))
 assert mobile.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), 'horizontal overflow home'
 mobile.locator('.mobile-menu').click()
 assert mobile.locator('#mobile-nav').is_visible()
 render(mobile,Path('articles/fire-tv-wifi-connect/index.html'))
 assert mobile.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), 'horizontal overflow article'
 mobile.screenshot(path=str(ROOT/'article-checklist-mobile.png'),full_page=False)
 assert not errors, 'JS console errors: '+str(errors)
 print('PASS - search, filtering, checklist, reset, local-storage retention, mobile menu, responsive widths')
 browser.close()
